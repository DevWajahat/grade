 <!-- Footer -->
 <footer class="footer py-4">
     <div class="container">
         <div class="row align-items-center">
             <div class="col-md-6">
                 <div class="footer-brand">
                     <i class="fas fa-graduation-cap me-2"></i>
                     <span>Grade Genius</span>
                 </div>
                 <p class="footer-text">Empowering educators with AI-powered grading solutions.</p>
             </div>
             <div class="col-md-6 text-md-end">
                 <div class="social-links">
                     <a href="#"><i class="fab fa-twitter"></i></a>
                     <a href="#"><i class="fab fa-linkedin"></i></a>
                     <a href="#"><i class="fab fa-facebook"></i></a>
                 </div>
                 <p class="footer-text mt-2">© 2024 Grade Genius. All rights reserved.</p>
             </div>
         </div>
     </div>
 </footer>

 <!-- Bootstrap JS -->
 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

 <!-- Custom JS -->
 <script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.7/dist/loadingoverlay.min.js"></script>
 <script src="{{ asset('assets/web/js/script.js') }}"></script>
 </body>

 </html>
