@include('includes.candidate.head')
@include('includes.candidate.header')

@yield('content')

@include('includes.candidate.footer')
