@include('includes.web.header')

@yield('content')

@include('includes.web.footer')
