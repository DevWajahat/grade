@include('includes.examiner.header')

@yield('content')

@include('includes.examiner.footer')
